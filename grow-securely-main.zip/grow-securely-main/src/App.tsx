import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Session, User } from "@supabase/supabase-js";
import Home from "./pages/Home";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import InvestmentSchemes from "./pages/InvestmentSchemes";
import InvestmentConfirmation from "./pages/InvestmentConfirmation";
import InvestmentSuccess from "./pages/InvestmentSuccess";
import AdminPanel from "./pages/AdminPanel";
import NotFound from "./pages/NotFound";
import LiveChat from "./components/LiveChat";

const queryClient = new QueryClient();

const App = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        setIsLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-primary">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-white/20 border-t-white rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={user ? <Dashboard /> : <Home />} />
            <Route path="/auth" element={user ? <Dashboard /> : <Auth />} />
            <Route path="/dashboard" element={user ? <Dashboard /> : <Auth />} />
            <Route path="/invest" element={user ? <InvestmentSchemes /> : <Auth />} />
            <Route path="/invest/confirm" element={user ? <InvestmentConfirmation /> : <Auth />} />
            <Route path="/investment-success" element={user ? <InvestmentSuccess /> : <Auth />} />
            <Route path="/admin" element={user ? <AdminPanel /> : <Auth />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          {user && <LiveChat />}
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
