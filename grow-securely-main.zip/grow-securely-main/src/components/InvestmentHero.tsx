import { Button } from "@/components/ui/button";
import { TrendingUp, Shield, Target } from "lucide-react";
import heroImage from "@/assets/hero-investment.jpg";

const InvestmentHero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Investment Growth"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-primary/80"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <h1 className="heading-hero mb-6">
            Grow Your Wealth with{" "}
            <span className="text-gold">Smart Investments</span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-white/90 leading-relaxed">
            Join thousands of investors who trust our platform for secure, 
            profitable investment opportunities with guaranteed returns.
          </p>
          
          {/* Feature Pills */}
          <div className="flex flex-wrap justify-center gap-4 mb-10">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
              <Shield className="w-5 h-5 text-gold" />
              <span>Secure & Regulated</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
              <TrendingUp className="w-5 h-5 text-gold" />
              <span>Up to 60% ROI</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
              <Target className="w-5 h-5 text-gold" />
              <span>Proven Track Record</span>
            </div>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="gold" size="xl" className="font-bold">
              Start Investing Now
            </Button>
            <Button variant="outline" size="xl" className="border-white text-white hover:bg-white hover:text-primary">
              View Investment Plans
            </Button>
          </div>
          
          {/* Trust Indicators */}
          <div className="mt-12 text-white/70">
            <p className="text-sm mb-4">Trusted by 10,000+ investors worldwide</p>
            <div className="flex justify-center items-center gap-8 text-xs">
              <div>$50M+ Invested</div>
              <div className="w-px h-4 bg-white/30"></div>
              <div>99.7% Success Rate</div>
              <div className="w-px h-4 bg-white/30"></div>
              <div>24/7 Support</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/60 animate-bounce">
        <div className="w-px h-16 bg-gradient-to-b from-white/60 to-transparent"></div>
      </div>
    </section>
  );
};

export default InvestmentHero;