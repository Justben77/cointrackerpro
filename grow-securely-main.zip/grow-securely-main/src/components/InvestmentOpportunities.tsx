import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  TrendingUp, 
  Building2, 
  Coins, 
  PiggyBank, 
  ArrowRight,
  Star,
  Clock,
  DollarSign
} from "lucide-react";

const opportunities = [
  {
    icon: TrendingUp,
    title: "Stock Market",
    description: "Diversified portfolio of blue-chip stocks with professional management",
    features: ["Professional Management", "Real-time Tracking", "Risk Mitigation"],
    roi: "12-18%",
    risk: "Medium",
    color: "text-blue-600"
  },
  {
    icon: Coins,
    title: "Cryptocurrency",
    description: "Digital asset investment with high growth potential and modern portfolio",
    features: ["24/7 Trading", "High Liquidity", "Future Technology"],
    roi: "25-45%",
    risk: "High",
    color: "text-orange-600"
  },
  {
    icon: Building2,
    title: "Real Estate",
    description: "Premium property investments with stable returns and asset appreciation",
    features: ["Stable Income", "Asset Appreciation", "Tax Benefits"],
    roi: "8-15%",
    risk: "Low",
    color: "text-green-600"
  },
  {
    icon: PiggyBank,
    title: "Fixed Income",
    description: "Government and corporate bonds offering guaranteed returns with security",
    features: ["Guaranteed Returns", "Capital Protection", "Regular Income"],
    roi: "6-10%",
    risk: "Very Low",
    color: "text-purple-600"
  }
];

const InvestmentOpportunities = () => {
  return (
    <section className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="heading-section mb-4">
            Diversified Investment <span className="text-gold">Opportunities</span>
          </h2>
          <p className="text-xl text-muted max-w-3xl mx-auto">
            Choose from our carefully curated investment options designed to match 
            your risk appetite and financial goals.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {opportunities.map((opportunity, index) => (
            <Card key={index} className="investment-card gradient-card border-0 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-20 h-20 bg-accent/10 rounded-full -translate-y-10 translate-x-10 group-hover:scale-150 transition-transform duration-500"></div>
              
              <CardHeader className="relative">
                <div className={`w-12 h-12 rounded-xl bg-white shadow-md flex items-center justify-center mb-4 ${opportunity.color}`}>
                  <opportunity.icon className="w-6 h-6" />
                </div>
                <CardTitle className="text-xl mb-2">{opportunity.title}</CardTitle>
                <CardDescription className="text-muted">
                  {opportunity.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* ROI and Risk */}
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-gold" />
                    <span className="font-semibold text-gold">{opportunity.roi} ROI</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${
                      opportunity.risk === 'Very Low' ? 'bg-green-500' :
                      opportunity.risk === 'Low' ? 'bg-green-400' :
                      opportunity.risk === 'Medium' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}></div>
                    <span className="text-sm text-muted">{opportunity.risk} Risk</span>
                  </div>
                </div>
                
                {/* Features */}
                <div className="space-y-2">
                  {opportunity.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary"></div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
                
                {/* CTA */}
                <Button 
                  variant="outline" 
                  className="w-full group-hover:bg-primary group-hover:text-white transition-colors"
                >
                  Learn More
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">Ready to Start Your Investment Journey?</h3>
            <p className="text-muted mb-6">
              Join our platform today and get access to all investment opportunities 
              with professional guidance and 24/7 support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg">
                <DollarSign className="w-5 h-5 mr-2" />
                Start Investing
              </Button>
              <Button variant="outline" size="lg">
                <Clock className="w-5 h-5 mr-2" />
                Schedule Consultation
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InvestmentOpportunities;