import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, Play, Star } from "lucide-react";
import TestimonialsVideo from "@/assets/Testimonials.mp4";

const testimonials = [
  {
    id: 1,
    name: "Mr. Craig",
    role: "Investment Consultant",
    rating: 5,
    text: "Coin Tracker Pro has transformed my investment strategy. The returns have been exceptional!",
    video: TestimonialsVideo,
  },
  {
    id: 2,
    name: "Mrs. Calisto",
    role: "Financial Advisor",
    rating: 5,
    text: "Professional platform with outstanding customer support. Highly recommended for serious investors.",
    video: TestimonialsVideo,
  },
  {
    id: 3,
    name: "Mr. Charles",
    role: "Business Owner",
    rating: 5,
    text: "The best investment platform I've used. Transparent, secure, and profitable.",
    video: TestimonialsVideo,
  },
];

const VideoTestimonySlider = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    setIsPlaying(false);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    setIsPlaying(false);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            What Our <span className="text-primary">Investors Say</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it. Hear from real investors who have achieved 
            remarkable success with Coin Tracker Pro.
          </p>
        </div>

        {/* Video Testimony Slider */}
        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden">
            <div className="grid md:grid-cols-2 gap-0">
              {/* Video Section */}
              <div className="relative bg-black aspect-video md:aspect-auto">
                <video
                  className="w-full h-full object-cover"
                  src={currentTestimonial.video}
                  poster=""
                  loop
                  playsInline
                  ref={(video) => {
                    if (video) {
                      if (isPlaying) {
                        video.play();
                      } else {
                        video.pause();
                      }
                    }
                  }}
                />
                
                {/* Play Button Overlay */}
                {!isPlaying && (
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <Button
                      size="lg"
                      className="rounded-full w-16 h-16 bg-primary hover:bg-primary/90"
                      onClick={togglePlay}
                    >
                      <Play className="w-6 h-6 text-white ml-1" />
                    </Button>
                  </div>
                )}
              </div>

              {/* Content Section */}
              <div className="p-8 flex flex-col justify-center">
                {/* Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>

                {/* Testimonial Text */}
                <blockquote className="text-lg mb-6 leading-relaxed">
                  "{currentTestimonial.text}"
                </blockquote>

                {/* Author */}
                <div className="mb-6">
                  <div className="font-semibold text-foreground">
                    {currentTestimonial.name}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {currentTestimonial.role}
                  </div>
                </div>

                {/* Navigation */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={prevTestimonial}
                      className="rounded-full w-10 h-10 p-0"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={nextTestimonial}
                      className="rounded-full w-10 h-10 p-0"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Dots Indicator */}
                  <div className="flex items-center gap-2">
                    {testimonials.map((_, index) => (
                      <button
                        key={index}
                        className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                          index === currentIndex ? "bg-primary" : "bg-muted"
                        }`}
                        onClick={() => {
                          setCurrentIndex(index);
                          setIsPlaying(false);
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default VideoTestimonySlider;