import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  TrendingUp, 
  Wallet, 
  PlusCircle, 
  MinusCircle,
  BarChart3,
  History,
  Settings,
  LogOut,
  MessageCircle,
  Star,
  Clock,
  DollarSign
} from "lucide-react";
import { Link } from "react-router-dom";

interface Profile {
  full_name: string;
  wallet_balance: string;
  email: string;
}

interface InvestmentScheme {
  id: string;
  name: string;
  description: string;
  roi_percentage: number;
  duration_days: number;
  minimum_deposit: number;
  maximum_deposit: number;
}

interface UserInvestment {
  id: string;
  amount: number;
  status: string;
  start_date: string;
  end_date: string;
  total_return: number;
  investment_schemes: InvestmentScheme;
}

const Dashboard = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [investments, setInvestments] = useState<UserInvestment[]>([]);
  const [schemes, setSchemes] = useState<InvestmentScheme[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        // Fetch profile
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('user_id', user.id)
          .single();

        // Fetch investments
        const { data: investmentData } = await supabase
          .from('user_investments')
          .select(`
            *,
            investment_schemes (*)
          `)
          .eq('user_id', user.id);

        // Fetch available schemes
        const { data: schemesData } = await supabase
          .from('investment_schemes')
          .select('*')
          .eq('is_active', true);

        setProfile(profileData);
        setInvestments(investmentData || []);
        setSchemes(schemesData || []);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      toast({
        title: "Error",
        description: "Failed to load dashboard data.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Signed Out",
      description: "You have been successfully signed out.",
    });
  };

  const totalInvested = investments.reduce((sum, inv) => sum + Number(inv.amount), 0);
  const totalReturns = investments.reduce((sum, inv) => sum + (Number(inv.total_return) || 0), 0);
  const activeInvestments = investments.filter(inv => inv.status === 'active').length;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background dark">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background dark">
      {/* Header */}
      <header className="bg-card shadow-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl gradient-gold flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-accent-foreground" />
                </div>
                <span className="text-xl font-bold text-foreground">Coin Tracker Pro</span>
              </div>
              <span className="text-muted">Welcome back, {profile?.full_name}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <a href="mailto:procointracker@gmail.com">
                <Button variant="outline" size="sm" className="border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Chat Support
                </Button>
              </a>
              <Button variant="logout" size="sm" onClick={handleSignOut}>
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="gradient-card investment-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Wallet Balance</CardTitle>
              <Wallet className="h-4 w-4 text-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gold">
                ${parseFloat(profile?.wallet_balance || '0.00').toFixed(2)}
              </div>
              <div className="flex gap-2 mt-4">
                <Link to="https://wallet-topup-pal.lovable.app" className="flex-1">
                <Button 
                  size="sm" 
                  variant="deposit" 
                  className="flex-2"
                  onClick={() => window.open('https://wallet-topup-pal.lovable.app', '_blank')}
                >
                  <PlusCircle className="w-4 h-4 mr-1" />
                  Deposit 
                  </Button>
                </Link>
                <Link to="https://nft-live-folio.lovable.app" className="flex-1">
                  <Button size="sm" variant="hero" className="w-full">
                    <DollarSign className="w-4 h-4 mr-1" />
                    Invest
                  </Button>
                </Link>
                <Button 
                  size="sm" 
                  variant="withdraw" 
                  className="flex-1"
                  onClick={() => window.open('https://cashout-corner.lovable.app', '_blank')}
                >
                  <MinusCircle className="w-4 h-4 mr-1" />
                  Withdraw
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="gradient-card investment-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Invested</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalInvested.toFixed(2)}</div>
              <p className="text-xs text-muted mt-1">
                Across {activeInvestments} active investments
              </p>
            </CardContent>
          </Card>

          <Card className="gradient-card investment-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Returns</CardTitle>
              <TrendingUp className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">${totalReturns.toFixed(2)}</div>
              <p className="text-xs text-muted mt-1">
                {totalInvested > 0 ? `+${((totalReturns / totalInvested) * 100).toFixed(1)}%` : '+0%'} profit
              </p>
            </CardContent>
          </Card>

          <Card className="gradient-card investment-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Plans</CardTitle>
              <Clock className="h-4 w-4 text-muted" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeInvestments}</div>
              <Link to="/invest">
                <Button size="sm" variant="outline" className="w-full mt-4">
                  <PlusCircle className="w-4 h-4 mr-1" />
                  New Investment
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="investments" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="investments">My Investments</TabsTrigger>
            <TabsTrigger value="schemes">Available Plans</TabsTrigger>
            <TabsTrigger value="history">Transaction History</TabsTrigger>
          </TabsList>

          <TabsContent value="investments" className="space-y-4">
            {investments.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <BarChart3 className="w-16 h-16 text-muted mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Investments Yet</h3>
                  <p className="text-muted mb-6">Start your investment journey by choosing a plan.</p>
                  <Link to="/invest">
                    <Button variant="hero">
                      <DollarSign className="w-4 h-4 mr-2" />
                      Explore Investment Plans
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {investments.map((investment) => (
                  <Card key={investment.id} className="investment-card">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {investment.investment_schemes.name}
                            <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                              investment.status === 'active' ? 'bg-success-light text-success' :
                              investment.status === 'completed' ? 'bg-accent-light text-accent-foreground' :
                              'bg-secondary text-secondary-foreground'
                            }`}>
                              {investment.status}
                            </div>
                          </CardTitle>
                          <CardDescription>
                            {investment.investment_schemes.description}
                          </CardDescription>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">${investment.amount}</div>
                          <div className="text-sm text-success">
                            +{investment.investment_schemes.roi_percentage}% ROI
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <div className="text-muted">Start Date</div>
                          <div className="font-medium">
                            {new Date(investment.start_date).toLocaleDateString()}
                          </div>
                        </div>
                        <div>
                          <div className="text-muted">End Date</div>
                          <div className="font-medium">
                            {new Date(investment.end_date).toLocaleDateString()}
                          </div>
                        </div>
                        <div>
                          <div className="text-muted">Duration</div>
                          <div className="font-medium">
                            {investment.investment_schemes.duration_days} days
                          </div>
                        </div>
                        <div>
                          <div className="text-muted">Expected Return</div>
                          <div className="font-medium text-success">
                            ${(Number(investment.amount) * (1 + investment.investment_schemes.roi_percentage / 100)).toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="schemes" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {schemes.map((scheme) => (
                <Card key={scheme.id} className="investment-card relative overflow-hidden">
                  <div className="absolute top-4 right-4">
                    <div className="flex items-center gap-1 bg-accent-light px-2 py-1 rounded-full">
                      <Star className="w-3 h-3 text-gold" />
                      <span className="text-xs font-medium text-gold">{scheme.roi_percentage}% ROI</span>
                    </div>
                  </div>
                  
                  <CardHeader>
                    <CardTitle className="text-xl">{scheme.name}</CardTitle>
                    <CardDescription>{scheme.description}</CardDescription>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-muted">Duration</div>
                        <div className="font-medium">{scheme.duration_days} days</div>
                      </div>
                      <div>
                        <div className="text-muted">Min. Deposit</div>
                        <div className="font-medium">${scheme.minimum_deposit}</div>
                      </div>
                    </div>
                    
                    <Button variant="hero" className="w-full">
                      <DollarSign className="w-4 h-4 mr-2" />
                      Invest Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Transaction History
                </CardTitle>
                <CardDescription>
                  View all your deposits, withdrawals, and investment transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted">
                  No transactions found. Start investing to see your transaction history.
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;
