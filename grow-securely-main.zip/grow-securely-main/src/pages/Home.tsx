import InvestmentHero from "@/components/InvestmentHero";
import InvestmentOpportunities from "@/components/InvestmentOpportunities";
import VideoTestimonySlider from "@/components/VideoTestimonySlider";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { LogIn, UserPlus, Shield, Award, Users, TrendingUp } from "lucide-react";

const stats = [
  { icon: Users, value: "10,000+", label: "Active Investors" },
  { icon: TrendingUp, value: "$50M+", label: "Total Invested" },
  { icon: Award, value: "99.7%", label: "Success Rate" },
  { icon: Shield, value: "5 Years", label: "Trusted Service" },
];

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="absolute top-0 left-0 right-0 z-50 bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl gradient-gold flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold text-white">Coin Tracker Pro</span>
            </div>
            
            <div className="flex items-center gap-4">
              <Link to="/auth">
                <Button variant="ghost" className="text-white hover:bg-white/20">
                  <LogIn className="w-4 h-4 mr-2" />
                  Login
                </Button>
              </Link>
              <Link to="/auth">
                <Button variant="gold" size="sm">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Sign Up
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <InvestmentHero />

      {/* Stats Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/10 flex items-center justify-center">
                  <stat.icon className="w-8 h-8 text-gold" />
                </div>
                <div className="text-3xl font-bold mb-2">{stat.value}</div>
                <div className="text-white/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Video Testimonials */}
      <VideoTestimonySlider />

      {/* Investment Opportunities */}
      <InvestmentOpportunities />

      {/* Footer */}
      <footer className="bg-primary text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl gradient-gold flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent-foreground" />
              </div>
              <span className="text-2xl font-bold">Coin Tracker Pro</span>
            </div>
            <p className="text-white/80 mb-6 max-w-2xl mx-auto">
              Your trusted partner in building wealth through smart, secure investments. 
              Start your journey to financial freedom today.
            </p>
            <div className="flex justify-center gap-4">
              <Link to="/auth">
                <Button variant="gold">
                  Get Started Today
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
