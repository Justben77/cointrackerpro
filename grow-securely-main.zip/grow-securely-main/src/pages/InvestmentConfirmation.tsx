import { useState, useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  CheckCircle, 
  Clock, 
  DollarSign,
  Shield,
  TrendingUp
} from "lucide-react";

interface InvestmentData {
  scheme: {
    id: string;
    name: string;
    description: string;
    roi_percentage: number;
    duration_days: number;
    minimum_deposit: number;
    maximum_deposit: number;
  };
  amount: number;
}

interface Profile {
  wallet_balance: string;
}

const InvestmentConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isInvesting, setIsInvesting] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  
  const investmentData = location.state as InvestmentData;

  useEffect(() => {
    if (!investmentData) {
      navigate('/invest');
      return;
    }
    fetchProfile();
  }, [investmentData, navigate]);

  const fetchProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data: profileData } = await supabase
          .from('profiles')
          .select('wallet_balance')
          .eq('user_id', user.id)
          .single();

        setProfile(profileData);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const handleConfirmInvestment = async () => {
    if (!investmentData || !profile) return;

    const { scheme, amount } = investmentData;

    if (amount > parseFloat(profile.wallet_balance)) {
      toast({
        title: "Insufficient Balance",
        description: "Please deposit funds to your wallet first.",
        variant: "destructive",
      });
      return;
    }

    setIsInvesting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + scheme.duration_days);

        // Create investment
        const { error: investError } = await supabase
          .from('user_investments')
          .insert({
            user_id: user.id,
            scheme_id: scheme.id,
            amount: amount,
            end_date: endDate.toISOString(),
            total_return: amount * (1 + scheme.roi_percentage / 100)
          });

        if (investError) throw investError;

        // Update wallet balance
        const { error: balanceError } = await supabase
          .from('profiles')
          .update({ 
            wallet_balance: (parseFloat(profile.wallet_balance) - amount).toString()
          })
          .eq('user_id', user.id);

        if (balanceError) throw balanceError;

        // Create transaction record
        const { error: transactionError } = await supabase
          .from('transactions')
          .insert({
            user_id: user.id,
            type: 'investment',
            amount: amount,
            status: 'completed',
            description: `Investment in ${scheme.name}`
          });

        if (transactionError) throw transactionError;

        toast({
          title: "Investment Successful!",
          description: `You have successfully invested $${amount} in ${scheme.name}`,
        });

        // Redirect to success page with investment data
        navigate('/investment-success', {
          state: {
            investmentId: Date.now().toString(), // Simple ID for now
            scheme: {
              name: scheme.name,
              roi_percentage: scheme.roi_percentage,
              duration_days: scheme.duration_days
            },
            amount: amount,
            expectedReturn: amount * (1 + scheme.roi_percentage / 100),
            endDate: endDate.toISOString()
          }
        });
      }
    } catch (error) {
      console.error('Error creating investment:', error);
      toast({
        title: "Investment Failed",
        description: "There was an error processing your investment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsInvesting(false);
    }
  };

  if (!investmentData) {
    return null;
  }

  const { scheme, amount } = investmentData;
  const expectedReturn = amount * (1 + scheme.roi_percentage / 100);
  const profit = expectedReturn - amount;

  return (
    <div className="min-h-screen bg-secondary/30">
      {/* Header */}
      <header className="bg-white shadow-md border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link to="/invest">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Plans
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl gradient-gold flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold">Confirm Investment</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Investment Summary */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-center">Investment Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Plan Details */}
              <div className="bg-primary-light p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-4">{scheme.name}</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-gold" />
                    <span>ROI: <strong className="text-gold">{scheme.roi_percentage}%</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted" />
                    <span>Duration: <strong>{scheme.duration_days} days</strong></span>
                  </div>
                </div>
              </div>

              {/* Investment Amount */}
              <div className="bg-white p-6 rounded-lg border">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-lg">Investment Amount</span>
                  <span className="text-2xl font-bold text-primary">${amount.toFixed(2)}</span>
                </div>
                
                {/* Expected Returns */}
                <div className="bg-success-light p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span>Expected Return</span>
                    <span className="text-xl font-bold text-success">${expectedReturn.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted">Total Profit</span>
                    <span className="font-semibold text-success">+${profit.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Wallet Balance */}
              <div className="bg-accent-light p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span>Current Wallet Balance</span>
                  <span className="font-bold">${parseFloat(profile?.wallet_balance || '0').toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center mt-2 text-sm">
                  <span className="text-muted">Balance After Investment</span>
                  <span className="font-semibold">
                    ${(parseFloat(profile?.wallet_balance || '0') - amount).toFixed(2)}
                  </span>
                </div>
              </div>
              {/*Deposit Wallet Barcode */} 
              <img 
                src="/walletbarcodefordeposit.jpg" 
                alt="Wallet Barcode for deposit" 
                className="w-[300px] h-[300px] object-contain rounded-lg border border-border mx-auto"
              />
              <p><strong>Wallet ID: TKUgBk8i6AzZsDTGtkAVEoSAisZbM3vfe9 </strong></p>
              {/* Security Info */}
              <div className="flex items-center gap-3 bg-primary-light p-4 rounded-lg">
                <Shield className="w-6 h-6 text-primary" />
                <div>
                  <div className="font-semibold">Secure Investment</div>
                  <div className="text-sm text-muted">Your investment is protected by our security protocols</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 pt-4">
                <Link to="/invest" className="flex-1">
                  <Button variant="outline" className="w-full">
                    Cancel
                  </Button>
                </Link>
                <Button 
                  variant="default" 
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={handleConfirmInvestment}
                  disabled={isInvesting}
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  {isInvesting ? "Processing..." : "Confirm & Invest"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default InvestmentConfirmation;
