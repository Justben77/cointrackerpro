import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  TrendingUp, 
  ArrowLeft, 
  Star, 
  Shield, 
  Clock, 
  DollarSign,
  Target,
  Award,
  CheckCircle
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

interface InvestmentScheme {
  id: string;
  name: string;
  description: string;
  roi_percentage: number;
  duration_days: number;
  minimum_deposit: number;
  maximum_deposit: number;
}

interface Profile {
  wallet_balance: string; 
}

const InvestmentSchemes = () => {
  const [schemes, setSchemes] = useState<InvestmentScheme[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [selectedScheme, setSelectedScheme] = useState<InvestmentScheme | null>(null);
  const [investmentAmount, setInvestmentAmount] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isInvesting, setIsInvesting] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        // Fetch schemes
        const { data: schemesData } = await supabase
          .from('investment_schemes')
          .select('*')
          .eq('is_active', true)
          .order('roi_percentage', { ascending: true });

        // Fetch user profile
        const { data: profileData } = await supabase
          .from('profiles')
          .select('wallet_balance')
          .eq('user_id', user.id)
          .single();

        setSchemes(schemesData || []);
        setProfile(profileData);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load investment schemes.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInvest = async () => {
    if (!selectedScheme || !investmentAmount) return;

    const amount = parseFloat(investmentAmount);
    
    if (amount < selectedScheme.minimum_deposit) {
      toast({
        title: "Invalid Amount",
        description: `Minimum investment is $${selectedScheme.minimum_deposit}`,
        variant: "destructive",
      });
      return;
    }

    if (selectedScheme.maximum_deposit && amount > selectedScheme.maximum_deposit) {
      toast({
        title: "Invalid Amount",
        description: `Maximum investment is $${selectedScheme.maximum_deposit}`,
        variant: "destructive",
      });
      return;
    }

    if (profile && amount > parseFloat(profile.wallet_balance)) {
      toast({
        title: "Insufficient Balance",
        description: "Please deposit funds to your wallet first.",
        variant: "destructive",
      });
      return;
    }

    setIsInvesting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + selectedScheme.duration_days);

        // Create investment
        const { error: investError } = await supabase
          .from('user_investments')
          .insert({
            user_id: user.id,
            scheme_id: selectedScheme.id,
            amount: amount,
            end_date: endDate.toISOString(),
            total_return: amount * (1 + selectedScheme.roi_percentage / 100)
          });

        if (investError) throw investError;

        // Update wallet balance
        const { error: balanceError } = await supabase
          .from('profiles')
          .update({ 
            wallet_balance: (parseFloat(profile?.wallet_balance || '0') - amount).toString()
          })
          .eq('user_id', user.id);

        if (balanceError) throw balanceError;

        // Create transaction record
        const { error: transactionError } = await supabase
          .from('transactions')
          .insert({
            user_id: user.id,
            type: 'investment',
            amount: amount,
            status: 'completed',
            description: `Investment in ${selectedScheme.name}`
          });

        if (transactionError) throw transactionError;

        toast({
          title: "Investment Successful!",
          description: `You have successfully invested $${amount} in ${selectedScheme.name}`,
        });

        setSelectedScheme(null);
        setInvestmentAmount("");
        fetchData(); // Refresh data
      }
    } catch (error) {
      console.error('Error creating investment:', error);
      toast({
        title: "Investment Failed",
        description: "There was an error processing your investment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsInvesting(false);
    }
  };

  const getSchemeColor = (roiPercentage: number) => {
    if (roiPercentage <= 15) return "text-green-600 bg-green-50";
    if (roiPercentage <= 30) return "text-blue-600 bg-blue-50";
    if (roiPercentage <= 45) return "text-purple-600 bg-purple-50";
    return "text-gold bg-accent-light";
  };

  const getSchemeIcon = (roiPercentage: number) => {
    if (roiPercentage <= 15) return Shield;
    if (roiPercentage <= 30) return Target;
    if (roiPercentage <= 45) return TrendingUp;
    return Award;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-secondary/30">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted">Loading investment plans...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary/30">
      {/* Header */}
      <header className="bg-white shadow-md border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl gradient-gold flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold">Investment Plans</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="heading-section mb-4">
            Choose Your <span className="text-gold">Investment Plan</span>
          </h1>
          <p className="text-xl text-muted max-w-3xl mx-auto mb-6">
            Select from our range of carefully designed investment schemes with guaranteed returns 
            and professional management.
          </p>
          <div className="bg-primary-light rounded-2xl p-4 max-w-md mx-auto">
            <div className="text-sm text-muted mb-1">Available Balance</div>
            <div className="text-2xl font-bold text-gold">
              ${parseFloat(profile?.wallet_balance || '0').toFixed(2)}
            </div>
          </div>
        </div>

        {/* Investment Schemes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {schemes.map((scheme, index) => {
            const IconComponent = getSchemeIcon(scheme.roi_percentage);
            const colorClass = getSchemeColor(scheme.roi_percentage);
            
            return (
              <Card key={scheme.id} className="investment-card relative overflow-hidden group">
                {/* Popular Badge for Gold Plan */}
                {scheme.name.includes('Gold') && (
                  <div className="absolute -top-2 -right-2 bg-accent text-accent-foreground px-3 py-1 rounded-bl-lg text-xs font-bold">
                    POPULAR
                  </div>
                )}
                
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl ${colorClass} flex items-center justify-center`}>
                    <IconComponent className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-xl mb-2">{scheme.name}</CardTitle>
                  <CardDescription className="text-center">
                    {scheme.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  {/* ROI Display */}
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gold mb-1">
                      {scheme.roi_percentage}%
                    </div>
                    <div className="text-sm text-muted">ROI</div>
                  </div>
                  
                  {/* Features */}
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted" />
                      <span>{scheme.duration_days} days duration</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-muted" />
                      <span>Min: ${scheme.minimum_deposit}</span>
                    </div>
                    {scheme.maximum_deposit && (
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-muted" />
                        <span>Max: ${scheme.maximum_deposit}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      <span>Guaranteed returns</span>
                    </div>
                  </div>
                  
                  {/* Investment Button */}
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant={scheme.name.includes('Gold') ? 'gold' : 'hero'} 
                        className="w-full"
                        onClick={() => setSelectedScheme(scheme)}
                      >
                        <Star className="w-4 h-4 mr-2" />
                        Invest Now
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Invest in {selectedScheme?.name}</DialogTitle>
                        <DialogDescription>
                          Enter the amount you want to invest in this plan.
                        </DialogDescription>
                      </DialogHeader>
                      
                      {selectedScheme && (
                        <div className="space-y-4">
                          {/* Plan Details */}
                          <div className="bg-primary-light p-4 rounded-lg space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span>ROI:</span>
                              <span className="font-bold text-gold">{selectedScheme.roi_percentage}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Duration:</span>
                              <span>{selectedScheme.duration_days} days</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Min Amount:</span>
                              <span>${selectedScheme.minimum_deposit}</span>
                            </div>
                            {selectedScheme.maximum_deposit && (
                              <div className="flex justify-between">
                                <span>Max Amount:</span>
                                <span>${selectedScheme.maximum_deposit}</span>
                              </div>
                            )}
                          </div>
                          
                          {/* Investment Amount */}
                          <div className="space-y-2">
                            <Label htmlFor="amount">Investment Amount</Label>
                            <Input
                              id="amount"
                              type="number"
                              placeholder={`Min $${selectedScheme.minimum_deposit}`}
                              value={investmentAmount}
                              onChange={(e) => setInvestmentAmount(e.target.value)}
                              min={selectedScheme.minimum_deposit}
                              max={selectedScheme.maximum_deposit}
                            />
                          </div>
                          
                          {/* Expected Return */}
                          {investmentAmount && (
                            <div className="bg-success-light p-4 rounded-lg">
                              <div className="text-sm text-muted mb-1">Expected Return</div>
                              <div className="text-xl font-bold text-success">
                                ${(parseFloat(investmentAmount) * (1 + selectedScheme.roi_percentage / 100)).toFixed(2)}
                              </div>
                              <div className="text-xs text-muted">
                                Profit: ${(parseFloat(investmentAmount) * (selectedScheme.roi_percentage / 100)).toFixed(2)}
                              </div>
                            </div>
                          )}
                          
                          <Button 
                            variant="hero" 
                            className="w-full" 
                            onClick={() => {
                              if (!investmentAmount || !selectedScheme) return;
                              
                              const amount = parseFloat(investmentAmount);
                              
                              if (amount < selectedScheme.minimum_deposit) {
                                toast({
                                  title: "Invalid Amount",
                                  description: `Minimum investment is $${selectedScheme.minimum_deposit}`,
                                  variant: "destructive",
                                });
                                return;
                              }

                              if (selectedScheme.maximum_deposit && amount > selectedScheme.maximum_deposit) {
                                toast({
                                  title: "Invalid Amount",
                                  description: `Maximum investment is $${selectedScheme.maximum_deposit}`,
                                  variant: "destructive",
                                });
                                return;
                              }

                              if (profile && amount > parseFloat(profile.wallet_balance)) {
                                toast({
                                  title: "Insufficient Balance",
                                  description: "Please deposit funds to your wallet first.",
                                  variant: "destructive",
                                });
                                return;
                              }

                              navigate('/invest/confirm', {
                                state: {
                                  scheme: selectedScheme,
                                  amount: amount
                                }
                              });
                            }}
                            disabled={!investmentAmount}
                          >
                            Confirm Investment
                          </Button>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom Info */}
        <div className="mt-16 text-center">
          <div className="bg-white rounded-2xl p-8 max-w-4xl mx-auto shadow-lg">
            <h3 className="text-2xl font-bold mb-4">Why Choose Our Investment Plans?</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
              <div className="text-center">
                <Shield className="w-12 h-12 text-primary mx-auto mb-3" />
                <h4 className="font-semibold mb-2">Secure & Regulated</h4>
                <p className="text-muted">All investments are backed by secure protocols and regulatory compliance.</p>
              </div>
              <div className="text-center">
                <TrendingUp className="w-12 h-12 text-success mx-auto mb-3" />
                <h4 className="font-semibold mb-2">Guaranteed Returns</h4>
                <p className="text-muted">Fixed ROI with guaranteed payouts on maturity dates.</p>
              </div>
              <div className="text-center">
                <Award className="w-12 h-12 text-gold mx-auto mb-3" />
                <h4 className="font-semibold mb-2">Expert Management</h4>
                <p className="text-muted">Professional portfolio management with 24/7 monitoring.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvestmentSchemes;
