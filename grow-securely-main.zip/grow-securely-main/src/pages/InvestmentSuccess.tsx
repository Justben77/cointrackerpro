import { useEffect, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  CheckCircle, 
  TrendingUp, 
  Clock, 
  DollarSign,
  Calendar,
  ArrowRight
} from "lucide-react";

interface InvestmentSuccessData {
  investmentId: string;
  scheme: {
    name: string;
    roi_percentage: number;
    duration_days: number;
  };
  amount: number;
  expectedReturn: number;
  endDate: string;
}

const InvestmentSuccess = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(5);
  
  const successData = location.state as InvestmentSuccessData;

  useEffect(() => {
    if (!successData) {
      navigate('/dashboard');
      return;
    }

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          navigate('/dashboard');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [successData, navigate]);

  if (!successData) {
    return null;
  }

  const { scheme, amount, expectedReturn, endDate } = successData;
  const profit = expectedReturn - amount;
  const maturityDate = new Date(endDate).toLocaleDateString();

  return (
    <div className="min-h-screen bg-secondary/30 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-success rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Investment Successful!</h1>
          <p className="text-muted-foreground">Your investment has been processed successfully</p>
        </div>

        {/* Investment Details Card */}
        <Card className="mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-primary">{scheme.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Investment Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-primary-light p-6 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <DollarSign className="w-6 h-6 text-primary" />
                  <span className="font-semibold">Investment Amount</span>
                </div>
                <div className="text-3xl font-bold text-primary">${amount.toFixed(2)}</div>
              </div>

              <div className="bg-success-light p-6 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <TrendingUp className="w-6 h-6 text-success" />
                  <span className="font-semibold">Expected Return</span>
                </div>
                <div className="text-3xl font-bold text-success">${expectedReturn.toFixed(2)}</div>
                <div className="text-sm text-success mt-1">+${profit.toFixed(2)} profit</div>
              </div>
            </div>

            {/* Investment Details */}
            <div className="bg-accent-light p-6 rounded-lg">
              <h3 className="font-semibold mb-4">Investment Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-gold" />
                  <span>ROI: <strong className="text-gold">{scheme.roi_percentage}%</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted" />
                  <span>Duration: <strong>{scheme.duration_days} days</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-muted" />
                  <span>Maturity: <strong>{maturityDate}</strong></span>
                </div>
              </div>
            </div>

            {/* Next Steps */}
            <div className="bg-white p-6 rounded-lg border">
              <h3 className="font-semibold mb-3">What's Next?</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Track your investment progress in your dashboard
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Receive notifications about your investment status
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Your returns will be credited automatically on maturity
                </li>
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => navigate('/invest')}
              >
                Make Another Investment
              </Button>
              <Button 
                variant="hero" 
                className="flex-1"
                onClick={() => navigate('/dashboard')}
              >
                Go to Dashboard
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            {/* Auto Redirect Notice */}
            <div className="text-center text-sm text-muted-foreground">
              Redirecting to dashboard in {countdown} seconds...
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InvestmentSuccess;