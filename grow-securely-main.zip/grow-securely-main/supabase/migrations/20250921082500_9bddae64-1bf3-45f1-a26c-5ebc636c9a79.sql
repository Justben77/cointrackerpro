-- Fix infinite recursion in profiles table policies
-- Drop the problematic admin policies that cause recursion
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update profiles" ON public.profiles;

-- Create new admin policies that don't cause recursion
-- First, let's create a simple function to check admin status without recursion
CREATE OR REPLACE FUNCTION public.is_admin(user_uuid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = user_uuid 
    AND role = 'admin'
    LIMIT 1
  );
$$;

-- Create new admin policies using the function
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (
  -- Allow users to see their own profile
  auth.uid() = user_id 
  OR 
  -- Allow admins to see all profiles (using function to avoid recursion)
  public.is_admin(auth.uid())
);

CREATE POLICY "Admins can update all profiles" 
ON public.profiles 
FOR UPDATE 
USING (
  -- Allow users to update their own profile
  auth.uid() = user_id 
  OR 
  -- Allow admins to update all profiles
  public.is_admin(auth.uid())
);