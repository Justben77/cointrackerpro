-- Fix infinite recursion in profiles table policies
-- Drop the problematic admin policies that cause recursion
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.profiles;

-- Create a function to check admin status without recursion
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT 
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT role FROM public.profiles WHERE user_id = auth.uid() LIMIT 1;
$$;

-- Create new admin policies using the function to avoid recursion
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (
  -- Allow users to see their own profile
  auth.uid() = user_id 
  OR 
  -- Allow admins to see all profiles (using function to avoid recursion)
  public.get_current_user_role() = 'admin'
);

CREATE POLICY "Admins can update all profiles" 
ON public.profiles 
FOR UPDATE 
USING (
  -- Allow users to update their own profile
  auth.uid() = user_id 
  OR 
  -- Allow admins to update all profiles
  public.get_current_user_role() = 'admin'
);