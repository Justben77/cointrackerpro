-- Create profile for existing user if it doesn't exist
INSERT INTO public.profiles (user_id, full_name, email, wallet_balance)
SELECT 
  '74934b8b-4394-4021-87fc-a0571b6bfd99'::uuid,
  'Project X',
  'ossaibennethonyenkachi@gmail.com',
  '4000'
WHERE NOT EXISTS (
  SELECT 1 FROM public.profiles 
  WHERE user_id = '74934b8b-4394-4021-87fc-a0571b6bfd99'::uuid
);