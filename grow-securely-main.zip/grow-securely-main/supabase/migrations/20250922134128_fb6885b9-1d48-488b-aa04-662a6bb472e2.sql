-- Update the default wallet balance to 0.00 for new users
ALTER TABLE public.profiles 
ALTER COLUMN wallet_balance SET DEFAULT '0.00';

-- Update existing users' wallet balance to 0.00
UPDATE public.profiles 
SET wallet_balance = '0.00';